/*
 *@author: lethabo
 * date: 12/9/18
 */

package config;

public interface EndPoint {

    String GET_ALLBREEDS = "breeds/list/all";
    String GET_SUBBREEDS = "breed/retriever/list";
    String GET_RANDOMIMAGE = "breed/retriever/golden/images/random";
}
